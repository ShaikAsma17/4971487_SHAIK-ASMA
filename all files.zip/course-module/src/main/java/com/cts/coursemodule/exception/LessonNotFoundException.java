package com.cts.coursemodule.exception;

public class LessonNotFoundException extends RuntimeException{
 
	public LessonNotFoundException(String message) {
		super(message);
	}
	
	
}
