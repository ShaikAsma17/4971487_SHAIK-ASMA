package com.cts.coursemodule.exception;

public class LessonAlreadyExistsException extends RuntimeException {

	public LessonAlreadyExistsException(String message) {
		super(message);
	}
}
