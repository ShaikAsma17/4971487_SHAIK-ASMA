package com.cts.reportsmodule.exception;

public class StudentNotEnrolledException extends RuntimeException {
	
	public StudentNotEnrolledException(String message) {
		super(message);
	}

}
