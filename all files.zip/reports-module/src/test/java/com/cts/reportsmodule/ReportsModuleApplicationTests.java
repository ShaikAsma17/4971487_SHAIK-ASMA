package com.cts.reportsmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportsModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
