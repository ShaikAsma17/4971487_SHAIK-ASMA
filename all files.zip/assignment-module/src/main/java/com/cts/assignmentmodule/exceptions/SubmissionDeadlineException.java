package com.cts.assignmentmodule.exceptions;

public class SubmissionDeadlineException extends RuntimeException {
     public SubmissionDeadlineException(String message) {
         super(message);
     }
}
