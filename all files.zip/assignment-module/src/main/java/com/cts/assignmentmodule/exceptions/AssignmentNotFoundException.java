package com.cts.assignmentmodule.exceptions;


public class AssignmentNotFoundException extends RuntimeException {
	public AssignmentNotFoundException(String message)
	{
		super(message);
	}
	
}