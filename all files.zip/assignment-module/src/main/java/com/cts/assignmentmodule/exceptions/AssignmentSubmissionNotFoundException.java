package com.cts.assignmentmodule.exceptions;

public class AssignmentSubmissionNotFoundException extends RuntimeException{
	public AssignmentSubmissionNotFoundException(String message)
	{
		super(message);
	}

}
