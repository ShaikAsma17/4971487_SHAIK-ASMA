package com.cts.assignmentmodule.exceptions;

public class StudentNotEnrolledException extends RuntimeException {
	
	public StudentNotEnrolledException(String message) {
		super(message);
	}

}
