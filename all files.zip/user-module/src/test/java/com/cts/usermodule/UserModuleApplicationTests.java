package com.cts.usermodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
