package com.cts.usermodule.enums;

public enum Roles {
	
	STUDENT,
	
	
	INSTRUCTOR,
	
	
	ADMIN
	
	
}
