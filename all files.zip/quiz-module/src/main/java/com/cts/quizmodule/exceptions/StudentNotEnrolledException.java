package com.cts.quizmodule.exceptions;

public class StudentNotEnrolledException extends RuntimeException {
	
	public StudentNotEnrolledException(String message) {
		super(message);
	}

}
