package com.cts.quizmodule.exceptions;

public class DuplicateQuestionException  extends RuntimeException {
     public  DuplicateQuestionException(String message) {
    	 super(message);
     }
}
