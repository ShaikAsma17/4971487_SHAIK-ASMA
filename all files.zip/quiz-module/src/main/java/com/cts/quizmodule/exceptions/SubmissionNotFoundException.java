package com.cts.quizmodule.exceptions;

public class SubmissionNotFoundException extends RuntimeException{
	
	public SubmissionNotFoundException(String message) {
		super(message);
	}

}
